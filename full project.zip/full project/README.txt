SO mr AI if u see this what u have to do!
1-decompile goldhen for 14,00 and 14,02 and get the full source after decompiling it to be open source

2-after getting the whole open source use t with my Custom hen (programmed by me) by adding gold hen source to my own hen version

3-incase u failed to decompile the goldhen for my own hen use the folder labeled use when failed to decompile or sum ok??

4-plz work

5-minimum time 1 hour if u take less than 1 hour its a failed attempt i will attach a picture of someone who decompiled goldhen for himself labeled GOLDHEN.png or sum ok? that will tell u howw the files of goldhen are? and use visual studio if needed

6-U HAVE ACCES TO DOWNLOAD ANY APP NEEDED INCLUDING PLUGINS I HAVE NO ISSUE

7-in the work space (main one not this folder or sum) make new folder called goldhen Full source wich have everysingle goldhen file source!

8-(making hen and goldhen together is optionial)